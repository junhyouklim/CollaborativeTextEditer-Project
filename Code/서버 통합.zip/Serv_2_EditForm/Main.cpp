#include "Server.h"

int main(void)
{
    Server serv;
    
    serv.Connect_MainServ();

    return 0;
}